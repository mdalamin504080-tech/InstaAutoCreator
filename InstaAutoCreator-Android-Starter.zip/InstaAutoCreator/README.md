# Insta Auto Creator

A starter Android Studio project for an Instagram account-setup assistant.

## Included
- Custom username input with basic format validation
- Generate Account button
- Opens Instagram's official signup page
- Clear notice for CAPTCHA, OTP, and other security checks

## Not included
- Automated account creation through private/unofficial endpoints
- CAPTCHA or 2FA bypass
- Password, cookie, or session-token extraction/storage
- Automated username availability scraping

## Build
1. Open this folder in Android Studio.
2. Allow Gradle sync to complete.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated APK on your Android device.

You need Android Studio and the Android SDK to build the APK.
