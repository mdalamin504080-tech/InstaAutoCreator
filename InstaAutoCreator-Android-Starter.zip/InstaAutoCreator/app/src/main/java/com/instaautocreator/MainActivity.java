package com.instaautocreator;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private EditText username;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int bg = Color.rgb(18, 12, 20);
        int panel = Color.rgb(37, 25, 39);
        int white = Color.WHITE;
        int pink = Color.rgb(193, 53, 132);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(36), dp(24), dp(24));
        scroll.addView(root);

        TextView logo = new TextView(this);
        logo.setText("◎");
        logo.setTextSize(48);
        logo.setTextColor(pink);
        logo.setGravity(Gravity.CENTER);
        root.addView(logo);

        TextView title = new TextView(this);
        title.setText("Insta Auto Creator");
        title.setTextSize(25);
        title.setTextColor(white);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Instagram account setup assistant");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(14);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.bottomMargin = dp(30);
        root.addView(subtitle, subLp);

        TextView label = new TextView(this);
        label.setText("Custom Instagram username");
        label.setTextColor(white);
        label.setTextSize(15);
        root.addView(label);

        username = new EditText(this);
        username.setSingleLine(true);
        username.setHint("e.g. my_custom_name");
        username.setHintTextColor(Color.GRAY);
        username.setTextColor(white);
        username.setPadding(dp(14), dp(12), dp(14), dp(12));
        username.setBackgroundColor(panel);
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(-1, -2);
        inputLp.topMargin = dp(10);
        inputLp.bottomMargin = dp(18);
        root.addView(username, inputLp);

        Button generate = new Button(this);
        generate.setText("GENERATE ACCOUNT");
        generate.setTextColor(white);
        generate.setBackgroundTintList(android.content.res.ColorStateList.valueOf(pink));
        root.addView(generate, new LinearLayout.LayoutParams(-1, dp(52)));

        status = new TextView(this);
        status.setText("Enter a username to begin.");
        status.setTextColor(Color.LTGRAY);
        status.setTextSize(14);
        status.setPadding(0, dp(18), 0, dp(18));
        root.addView(status);

        TextView note = new TextView(this);
        note.setText("For account creation, Instagram may ask you to sign in and complete CAPTCHA, OTP, or other security checks yourself. This app does not collect passwords, cookies, or session tokens.");
        note.setTextColor(Color.rgb(190, 180, 190));
        note.setTextSize(12);
        note.setPadding(dp(14), dp(14), dp(14), dp(14));
        note.setBackgroundColor(panel);
        root.addView(note);

        TextView facebook = new TextView(this);
        facebook.setText("Facebook linking is handled through Meta's official account flow, not by storing your Facebook login in this app.");
        facebook.setTextColor(Color.LTGRAY);
        facebook.setTextSize(12);
        facebook.setPadding(0, dp(20), 0, 0);
        root.addView(facebook);

        generate.setOnClickListener(v -> {
            String name = username.getText().toString().trim();
            if (!name.matches("[A-Za-z0-9._]{1,30}")) {
                status.setText("Use 1–30 characters: letters, numbers, dots, or underscores.");
                return;
            }
            status.setText("Opening Instagram's official signup page. Check username availability and complete any security steps there.");
            Intent intent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.instagram.com/accounts/emailsignup/"));
            startActivity(intent);
        });

        setContentView(scroll);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
